
const functions = require("firebase-functions");
const admin = require("firebase-admin");
admin.initializeApp();
exports.cleanupOldStories = functions.pubsub.schedule("every 24 hours").onRun(async () => {
  const now = Date.now();
  const ref = admin.firestore().collection("stories");
  const snap = await ref.where("timestamp", "<", now - 24*60*60*1000).get();
  const batch = admin.firestore().batch();
  snap.forEach(doc => batch.delete(doc.ref));
  await batch.commit();
});
